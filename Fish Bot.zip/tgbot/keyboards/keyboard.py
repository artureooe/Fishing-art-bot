from tgbot.keyboards.keyboards_menu import main_menu
from tgbot.keyboards.keyboards_admin import admin


class keyboard:
	main_menu = main_menu()
	admin = admin()